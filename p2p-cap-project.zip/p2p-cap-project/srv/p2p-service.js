'use strict';

const cds = require('@sap/cds');

/**
 * SAP CAP Service Implementation
 * Procure-to-Pay (P2P) – ABC Manufacturing Pvt. Ltd.
 * Module: SAP MM | Platform: SAP BTP
 */
module.exports = class P2PService extends cds.ApplicationService {

  async init() {

    const {
      Vendors, Materials,
      PurchaseRequisitions, PR_Items,
      PurchaseOrders, PO_Items,
      GoodsReceipts, GR_Items,
      Invoices, Invoice_Items
    } = this.entities;

    // ─── AUTO-GENERATE DOCUMENT NUMBERS ─────────────────────────────────────

    // Generate PR Number before insert
    this.before('CREATE', PurchaseRequisitions, async (req) => {
      const count = await SELECT.one`count(*) as cnt`.from(PurchaseRequisitions);
      const num = String((count?.cnt || 0) + 1).padStart(8, '0');
      req.data.prNumber = `PR-${new Date().getFullYear()}-${num}`;
    });

    // Generate PO Number before insert
    this.before('CREATE', PurchaseOrders, async (req) => {
      const count = await SELECT.one`count(*) as cnt`.from(PurchaseOrders);
      const num = String((count?.cnt || 0) + 1).padStart(8, '0');
      req.data.poNumber = `PO-${new Date().getFullYear()}-${num}`;
      // Calculate total value from items if provided
      if (req.data.items && req.data.items.length > 0) {
        req.data.totalValue = req.data.items.reduce((sum, item) => {
          const total = (item.quantity || 0) * (item.netPrice || 0);
          item.totalPrice = total;
          return sum + total;
        }, 0);
      }
    });

    // Generate GR Number before insert
    this.before('CREATE', GoodsReceipts, async (req) => {
      const count = await SELECT.one`count(*) as cnt`.from(GoodsReceipts);
      const num = String((count?.cnt || 0) + 1).padStart(8, '0');
      req.data.grNumber = `GR-${new Date().getFullYear()}-${num}`;
      req.data.postingDate = req.data.postingDate || new Date().toISOString().split('T')[0];
    });

    // ─── AFTER GR: UPDATE STOCK & PO DELIVERED QTY ───────────────────────────
    this.after('CREATE', GoodsReceipts, async (result, req) => {
      if (!result || !result.items) return;

      const grItems = await SELECT.from(GR_Items).where({ gr_ID: result.ID });

      for (const item of grItems) {
        // Update material stock
        const mat = await SELECT.one.from(Materials).where({ ID: item.material_ID });
        if (mat) {
          await UPDATE(Materials)
            .set({ stockQty: (mat.stockQty || 0) + item.receivedQty })
            .where({ ID: item.material_ID });
        }

        // Update PO item delivered quantity
        if (item.poItem_ID) {
          const poItem = await SELECT.one.from(PO_Items).where({ ID: item.poItem_ID });
          if (poItem) {
            const newDelivered = (poItem.deliveredQty || 0) + item.receivedQty;
            await UPDATE(PO_Items)
              .set({ deliveredQty: newDelivered })
              .where({ ID: item.poItem_ID });
          }
        }
      }

      // Update PO status
      const gr = await SELECT.one.from(GoodsReceipts).where({ ID: result.ID });
      if (gr && gr.po_ID) {
        const poItems = await SELECT.from(PO_Items).where({ po_ID: gr.po_ID });
        const allDelivered = poItems.every(i => (i.deliveredQty || 0) >= (i.quantity || 0));
        const anyDelivered = poItems.some(i => (i.deliveredQty || 0) > 0);
        const newStatus = allDelivered ? 'FullyReceived' : anyDelivered ? 'PartiallyReceived' : 'Open';
        await UPDATE(PurchaseOrders).set({ status: newStatus }).where({ ID: gr.po_ID });
      }
    });

    // ─── BEFORE INVOICE: SET NET AMOUNT & DUE DATE ───────────────────────────
    this.before('CREATE', Invoices, async (req) => {
      const gross = req.data.grossAmount || 0;
      const tax   = req.data.taxAmount   || 0;
      req.data.netAmount   = gross + tax;
      req.data.postingDate = req.data.postingDate || new Date().toISOString().split('T')[0];

      // Calculate due date (default 30 days)
      const invoice_date = new Date(req.data.invoiceDate || new Date());
      invoice_date.setDate(invoice_date.getDate() + 30);
      req.data.dueDate = invoice_date.toISOString().split('T')[0];
    });

    // ─── ACTION: APPROVE PURCHASE REQUISITION ────────────────────────────────
    this.on('approvePR', async (req) => {
      const { prID } = req.data;
      const pr = await SELECT.one.from(PurchaseRequisitions).where({ ID: prID });

      if (!pr)
        return req.error(404, `Purchase Requisition not found: ${prID}`);
      if (pr.status !== 'Open')
        return req.error(400, `PR cannot be approved. Current status: ${pr.status}`);

      await UPDATE(PurchaseRequisitions).set({ status: 'Approved' }).where({ ID: prID });
      return { message: `PR ${pr.prNumber} approved successfully.`, status: 'Approved' };
    });

    // ─── ACTION: CONVERT PR TO PO ────────────────────────────────────────────
    this.on('convertPRtoPO', async (req) => {
      const { prID, vendorID } = req.data;

      const pr = await SELECT.one.from(PurchaseRequisitions).where({ ID: prID });
      if (!pr)          return req.error(404, `PR not found: ${prID}`);
      if (pr.status !== 'Approved')
        return req.error(400, `Only Approved PRs can be converted to PO. Current: ${pr.status}`);

      const vendor = await SELECT.one.from(Vendors).where({ ID: vendorID });
      if (!vendor)      return req.error(404, `Vendor not found: ${vendorID}`);

      const prItems = await SELECT.from(PR_Items).where({ pr_ID: prID });
      if (!prItems || prItems.length === 0)
        return req.error(400, 'PR has no items.');

      // Build PO items from PR items
      const poItems = prItems.map((item, idx) => ({
        lineNo:      idx + 1,
        material_ID: item.material_ID,
        quantity:    item.quantity,
        uom:         item.uom,
        netPrice:    item.estimatedPrice || 0,
        totalPrice:  (item.quantity || 0) * (item.estimatedPrice || 0),
        plant:       item.plant,
        storageLoc:  item.storageLoc
      }));

      const totalValue = poItems.reduce((s, i) => s + (i.totalPrice || 0), 0);

      // Generate PO number
      const count = await SELECT.one`count(*) as cnt`.from(PurchaseOrders);
      const num   = String((count?.cnt || 0) + 1).padStart(8, '0');
      const poNumber = `PO-${new Date().getFullYear()}-${num}`;

      // Create PO
      const po = await INSERT.into(PurchaseOrders).entries({
        poNumber,
        vendor_ID:    vendorID,
        pr_ID:        prID,
        totalValue,
        currency:     'INR',
        paymentTerms: vendor.paymentTerms,
        status:       'Open',
        purchaseOrg:  'PURC',
        purchaseGrp:  'PG01',
        companyCode:  'ABC1',
        items:        poItems
      });

      // Mark PR as converted
      await UPDATE(PurchaseRequisitions).set({ status: 'Converted' }).where({ ID: prID });

      return { message: `PO ${poNumber} created successfully from PR ${pr.prNumber}.`, poNumber };
    });

    // ─── ACTION: POST GOODS RECEIPT ──────────────────────────────────────────
    this.on('postGoodsReceipt', async (req) => {
      const { poID } = req.data;
      const po = await SELECT.one.from(PurchaseOrders).where({ ID: poID });

      if (!po) return req.error(404, `PO not found: ${poID}`);
      if (po.status === 'FullyReceived' || po.status === 'Cancelled')
        return req.error(400, `Goods Receipt not possible. PO Status: ${po.status}`);

      const poItems = await SELECT.from(PO_Items).where({ po_ID: poID });
      if (!poItems || poItems.length === 0)
        return req.error(400, 'PO has no items.');

      const count = await SELECT.one`count(*) as cnt`.from(GoodsReceipts);
      const num   = String((count?.cnt || 0) + 1).padStart(8, '0');
      const grNumber = `GR-${new Date().getFullYear()}-${num}`;

      // GR items = remaining quantity to be received
      const grItems = poItems.map(item => ({
        poItem_ID:   item.ID,
        material_ID: item.material_ID,
        receivedQty: (item.quantity || 0) - (item.deliveredQty || 0),
        uom:         item.uom,
        storageLoc:  item.storageLoc || 'SL01'
      })).filter(i => i.receivedQty > 0);

      if (grItems.length === 0)
        return req.error(400, 'All quantities already received for this PO.');

      await INSERT.into(GoodsReceipts).entries({
        grNumber,
        po_ID:       poID,
        movementType:'101',
        postingDate: new Date().toISOString().split('T')[0],
        status:      'Posted',
        items:       grItems
      });

      return { message: `Goods Receipt ${grNumber} posted successfully.`, grNumber };
    });

    // ─── ACTION: THREE-WAY MATCH & VERIFY INVOICE ────────────────────────────
    this.on('verifyInvoice', async (req) => {
      const { invoiceID } = req.data;
      const invoice = await SELECT.one.from(Invoices).where({ ID: invoiceID });

      if (!invoice) return req.error(404, `Invoice not found: ${invoiceID}`);
      if (invoice.status !== 'Pending')
        return req.error(400, `Invoice already processed. Status: ${invoice.status}`);

      const po = await SELECT.one.from(PurchaseOrders).where({ ID: invoice.po_ID });
      if (!po) return req.error(404, 'Related PO not found.');

      // Three-way match logic:
      // 1. PO exists and is not cancelled
      // 2. GR is posted for this PO
      // 3. Invoice amount is within 5% tolerance of PO value
      const grs = await SELECT.from(GoodsReceipts).where({ po_ID: invoice.po_ID, status: 'Posted' });
      const grPosted = grs && grs.length > 0;

      const tolerance = 0.05;
      const amountOk  = po.totalValue
        ? Math.abs(invoice.grossAmount - po.totalValue) / po.totalValue <= tolerance
        : false;

      const threeWayMatch = po.status !== 'Cancelled' && grPosted && amountOk;
      const newStatus     = threeWayMatch ? 'Verified' : 'Blocked';

      await UPDATE(Invoices)
        .set({ status: newStatus, threeWayMatch })
        .where({ ID: invoiceID });

      // Update PO status if invoice verified
      if (threeWayMatch) {
        await UPDATE(PurchaseOrders).set({ status: 'Invoiced' }).where({ ID: po.ID });
      }

      return {
        message: threeWayMatch
          ? `Invoice verified. Three-way match successful. Status: Verified.`
          : `Invoice blocked. Three-way match failed (GR posted: ${grPosted}, Amount match: ${amountOk}).`,
        threeWayMatch
      };
    });

    // ─── FUNCTION: DASHBOARD SUMMARY ─────────────────────────────────────────
    this.on('getP2PSummary', async (req) => {
      const [prCount, openPOs, pendingGRs, pendingInvoices, spendResult] = await Promise.all([
        SELECT.one`count(*) as cnt`.from(PurchaseRequisitions),
        SELECT.one`count(*) as cnt`.from(PurchaseOrders).where({ status: 'Open' }),
        SELECT.one`count(*) as cnt`.from(PurchaseOrders).where({ status: ['Open','PartiallyReceived'] }),
        SELECT.one`count(*) as cnt`.from(Invoices).where({ status: 'Pending' }),
        SELECT.one`sum(totalValue) as total`.from(PurchaseOrders).where({ status: { '!=': 'Cancelled' } })
      ]);

      return {
        totalPRs:        prCount?.cnt        || 0,
        openPOs:         openPOs?.cnt        || 0,
        pendingGRs:      pendingGRs?.cnt     || 0,
        pendingInvoices: pendingInvoices?.cnt || 0,
        totalSpend:      spendResult?.total  || 0
      };
    });

    await super.init();
  }
};
