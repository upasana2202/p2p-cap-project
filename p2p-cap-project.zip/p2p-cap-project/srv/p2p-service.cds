using { com.abc.p2p as db } from '../db/schema';

service P2PService @(path: '/p2p') {

  // ─── VENDOR ──────────────────────────────────────────────────────
  entity Vendors          as projection on db.Vendors;

  // ─── MATERIAL ────────────────────────────────────────────────────
  entity Materials        as projection on db.Materials;

  // ─── PURCHASE REQUISITION ────────────────────────────────────────
  entity PurchaseRequisitions as projection on db.PurchaseRequisitions;
  entity PR_Items         as projection on db.PR_Items;

  // ─── PURCHASE ORDER ──────────────────────────────────────────────
  entity PurchaseOrders   as projection on db.PurchaseOrders;
  entity PO_Items         as projection on db.PO_Items;

  // ─── GOODS RECEIPT ───────────────────────────────────────────────
  entity GoodsReceipts    as projection on db.GoodsReceipts;
  entity GR_Items         as projection on db.GR_Items;

  // ─── INVOICE VERIFICATION ────────────────────────────────────────
  entity Invoices         as projection on db.Invoices;
  entity Invoice_Items    as projection on db.Invoice_Items;

  // ─── ACTIONS ─────────────────────────────────────────────────────
  action approvePR(prID: UUID)           returns { message: String; status: String; };
  action convertPRtoPO(prID: UUID, vendorID: UUID) returns { message: String; poNumber: String; };
  action postGoodsReceipt(poID: UUID)    returns { message: String; grNumber: String; };
  action verifyInvoice(invoiceID: UUID)  returns { message: String; threeWayMatch: Boolean; };

  // ─── FUNCTION (READ-ONLY) ─────────────────────────────────────────
  function getP2PSummary()               returns {
    totalPRs: Integer; openPOs: Integer;
    pendingGRs: Integer; pendingInvoices: Integer;
    totalSpend: Decimal(15,2);
  };
}
