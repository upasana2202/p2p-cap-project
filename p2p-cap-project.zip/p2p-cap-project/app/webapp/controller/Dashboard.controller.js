sap.ui.define([
  'sap/ui/core/mvc/Controller',
  'sap/ui/model/json/JSONModel',
  'sap/m/MessageToast'
], function (Controller, JSONModel, MessageToast) {
  'use strict';

  return Controller.extend('com.abc.p2p.fiori.controller.Dashboard', {

    onInit: function () {
      // Initialize dashboard model
      const oDashboardModel = new JSONModel({
        totalPRs: 0, openPOs: 0, pendingGRs: 0,
        pendingInvoices: 0, totalSpend: 0
      });
      this.getView().setModel(oDashboardModel, 'dashboard');
      this._loadSummary();
    },

    _loadSummary: function () {
      const oModel = this.getOwnerComponent().getModel();
      oModel.bindContext('/getP2PSummary(...)').requestObject().then((data) => {
        this.getView().getModel('dashboard').setData(data);
      }).catch(() => {
        MessageToast.show('Could not load dashboard summary.');
      });
    },

    onNavToPR:      function () { this.getOwnerComponent().getRouter().navTo('PRList'); },
    onNavToPO:      function () { this.getOwnerComponent().getRouter().navTo('POList'); },
    onNavToGR:      function () { this.getOwnerComponent().getRouter().navTo('GRList'); },
    onNavToInvoice: function () { this.getOwnerComponent().getRouter().navTo('InvoiceList'); },

    onPOPress: function (oEvent) {
      const ctx   = oEvent.getSource().getBindingContext();
      const poId  = ctx.getObject().ID;
      this.getOwnerComponent().getRouter().navTo('PODetail', { poId });
    }
  });
});
