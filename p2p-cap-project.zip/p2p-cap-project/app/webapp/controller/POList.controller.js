sap.ui.define([
  'sap/ui/core/mvc/Controller',
  'sap/ui/model/Filter',
  'sap/ui/model/FilterOperator',
  'sap/m/MessageToast',
  'sap/m/MessageBox'
], function (Controller, Filter, FilterOperator, MessageToast, MessageBox) {
  'use strict';

  return Controller.extend('com.abc.p2p.fiori.controller.POList', {

    onInit: function () {
      this.getOwnerComponent().getRouter()
        .getRoute('POList').attachPatternMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function () {
      this.getView().byId('poList').getBinding('items').refresh();
    },

    onNavBack: function () {
      this.getOwnerComponent().getRouter().navTo('Dashboard');
    },

    onSearch: function (oEvent) {
      const sQuery = oEvent.getParameter('query');
      const aFilters = [];
      if (sQuery) {
        aFilters.push(new Filter({
          filters: [
            new Filter('poNumber', FilterOperator.Contains, sQuery),
            new Filter('vendor/vendorName', FilterOperator.Contains, sQuery)
          ],
          and: false
        }));
      }
      this.getView().byId('poList').getBinding('items').filter(aFilters);
    },

    onFilterChange: function (oEvent) {
      const sKey = oEvent.getParameter('selectedItem').getKey();
      const aFilters = sKey !== 'All'
        ? [new Filter('status', FilterOperator.EQ, sKey)]
        : [];
      this.getView().byId('poList').getBinding('items').filter(aFilters);
    },

    onPODetailPress: function (oEvent) {
      const poId = oEvent.getSource().getBindingContext().getObject().ID;
      this.getOwnerComponent().getRouter().navTo('PODetail', { poId });
    },

    onPostGR: function (oEvent) {
      const oCtx   = oEvent.getSource().getParent().getParent().getBindingContext();
      const po     = oCtx.getObject();
      const oModel = this.getOwnerComponent().getModel();

      MessageBox.confirm(`Post Goods Receipt for PO ${po.poNumber}?`, {
        onClose: (action) => {
          if (action !== MessageBox.Action.OK) return;
          oModel.bindContext('/postGoodsReceipt(...)').setParameter('poID', po.ID)
            .execute().then((res) => {
              MessageToast.show(res.message || 'GR posted successfully.');
              oCtx.getBinding().refresh();
            }).catch(() => MessageBox.error('Failed to post Goods Receipt.'));
        }
      });
    },

    onAddInvoice: function (oEvent) {
      MessageToast.show('Navigate to Invoice creation – implement as per project extension.');
    },

    onCreatePO: function () {
      MessageToast.show('Create PO dialog – implement as per project extension.');
    }
  });
});
