sap.ui.define([
  'sap/ui/core/mvc/Controller',
  'sap/m/MessageToast',
  'sap/m/MessageBox'
], function (Controller, MessageToast, MessageBox) {
  'use strict';

  return Controller.extend('com.abc.p2p.fiori.controller.InvoiceList', {

    onNavBack: function () {
      this.getOwnerComponent().getRouter().navTo('Dashboard');
    },

    onVerifyInvoice: function (oEvent) {
      const oCtx     = oEvent.getSource().getParent().getParent().getBindingContext();
      const invoice  = oCtx.getObject();
      const oModel   = this.getOwnerComponent().getModel();

      MessageBox.confirm(`Run Three-Way Match and verify Invoice ${invoice.invoiceNo}?`, {
        onClose: (action) => {
          if (action !== MessageBox.Action.OK) return;
          oModel.bindContext('/verifyInvoice(...)').setParameter('invoiceID', invoice.ID)
            .execute().then((res) => {
              MessageToast.show(res.message);
              oCtx.getBinding().refresh();
            }).catch(() => MessageBox.error('Invoice verification failed.'));
        }
      });
    }
  });
});
