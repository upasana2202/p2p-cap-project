namespace com.abc.p2p;

using { cuid, managed, sap.common.CodeList } from '@sap/cds/common';

// ─── VENDOR MASTER ───────────────────────────────────────────────────────────
entity Vendors : cuid, managed {
  vendorCode   : String(10)  @mandatory;
  vendorName   : String(100) @mandatory;
  gstin        : String(15);
  email        : String(100);
  phone        : String(15);
  address      : String(255);
  city         : String(50);
  country      : String(50) default 'India';
  paymentTerms : String(50) default '30 days net';
  isActive     : Boolean    default true;
  purchaseOrders : Association to many PurchaseOrders on purchaseOrders.vendor = $self;
}

// ─── MATERIAL MASTER ─────────────────────────────────────────────────────────
entity Materials : cuid, managed {
  materialCode : String(20)  @mandatory;
  description  : String(200) @mandatory;
  uom          : String(10)  default 'KG';
  materialType : String(10)  default 'ROH';   // ROH = Raw Material
  plant        : String(10)  default 'PL01';
  storageLoc   : String(10)  default 'SL01';
  stockQty     : Decimal(13,3) default 0;
  valuationClass : String(10) default 'BSX';
}

// ─── PURCHASE REQUISITION ────────────────────────────────────────────────────
entity PurchaseRequisitions : cuid, managed {
  prNumber     : String(20)  @readonly;
  status       : String(20)  default 'Open'
                 @assert.range enum { Open; Approved; Converted; Cancelled; };
  requestedBy  : String(100);
  requiredDate : Date        @mandatory;
  items        : Composition of many PR_Items on items.pr = $self;
}

entity PR_Items : cuid {
  pr           : Association to PurchaseRequisitions @mandatory;
  material     : Association to Materials @mandatory;
  quantity     : Decimal(13,3) @mandatory;
  uom          : String(10)  default 'KG';
  plant        : String(10)  default 'PL01';
  storageLoc   : String(10)  default 'SL01';
  purchaseGrp  : String(10)  default 'PG01';
  estimatedPrice : Decimal(15,2);
}

// ─── PURCHASE ORDER ──────────────────────────────────────────────────────────
entity PurchaseOrders : cuid, managed {
  poNumber     : String(20)  @readonly;
  vendor       : Association to Vendors @mandatory;
  companyCode  : String(10)  default 'ABC1';
  purchaseOrg  : String(10)  default 'PURC';
  purchaseGrp  : String(10)  default 'PG01';
  currency     : String(5)   default 'INR';
  totalValue   : Decimal(15,2);
  status       : String(20)  default 'Open'
                 @assert.range enum { Open; PartiallyReceived; FullyReceived; Invoiced; Closed; Cancelled; };
  deliveryDate : Date;
  paymentTerms : String(50)  default '30 days net';
  pr           : Association to PurchaseRequisitions;
  items        : Composition of many PO_Items on items.po = $self;
  goodsReceipts : Association to many GoodsReceipts on goodsReceipts.po = $self;
  invoices     : Association to many Invoices on invoices.po = $self;
}

entity PO_Items : cuid {
  po           : Association to PurchaseOrders @mandatory;
  lineNo       : Integer;
  material     : Association to Materials @mandatory;
  quantity     : Decimal(13,3) @mandatory;
  uom          : String(10)  default 'KG';
  netPrice     : Decimal(15,2) @mandatory;
  totalPrice   : Decimal(15,2);
  plant        : String(10)  default 'PL01';
  storageLoc   : String(10)  default 'SL01';
  deliveredQty : Decimal(13,3) default 0;
  invoicedQty  : Decimal(13,3) default 0;
}

// ─── GOODS RECEIPT ───────────────────────────────────────────────────────────
entity GoodsReceipts : cuid, managed {
  grNumber     : String(20)  @readonly;
  po           : Association to PurchaseOrders @mandatory;
  movementType : String(5)   default '101';
  postingDate  : Date;
  status       : String(20)  default 'Posted'
                 @assert.range enum { Posted; Reversed; };
  items        : Composition of many GR_Items on items.gr = $self;
}

entity GR_Items : cuid {
  gr           : Association to GoodsReceipts @mandatory;
  poItem       : Association to PO_Items;
  material     : Association to Materials @mandatory;
  receivedQty  : Decimal(13,3) @mandatory;
  uom          : String(10)  default 'KG';
  storageLoc   : String(10)  default 'SL01';
  batchNo      : String(20);
}

// ─── INVOICE VERIFICATION ────────────────────────────────────────────────────
entity Invoices : cuid, managed {
  invoiceNo    : String(30)  @mandatory;
  po           : Association to PurchaseOrders @mandatory;
  vendor       : Association to Vendors @mandatory;
  invoiceDate  : Date        @mandatory;
  postingDate  : Date;
  grossAmount  : Decimal(15,2) @mandatory;
  taxAmount    : Decimal(15,2) default 0;
  netAmount    : Decimal(15,2);
  currency     : String(5)   default 'INR';
  paymentTerms : String(50);
  dueDate      : Date;
  status       : String(20)  default 'Pending'
                 @assert.range enum { Pending; Verified; Blocked; Paid; Cancelled; };
  threeWayMatch : Boolean    default false;
  items        : Composition of many Invoice_Items on items.invoice = $self;
}

entity Invoice_Items : cuid {
  invoice      : Association to Invoices @mandatory;
  poItem       : Association to PO_Items;
  material     : Association to Materials @mandatory;
  quantity     : Decimal(13,3);
  unitPrice    : Decimal(15,2);
  amount       : Decimal(15,2);
}

// ─── ANNOTATIONS FOR FIORI ───────────────────────────────────────────────────
annotate Vendors with @(
  UI.HeaderInfo: { TypeName: 'Vendor', TypeNamePlural: 'Vendors', Title: { Value: vendorName } },
  UI.LineItem: [
    { Value: vendorCode, Label: 'Vendor Code' },
    { Value: vendorName, Label: 'Vendor Name' },
    { Value: gstin,      Label: 'GSTIN' },
    { Value: paymentTerms, Label: 'Payment Terms' },
    { Value: isActive,   Label: 'Active' }
  ],
  UI.FieldGroup #GeneralInfo: {
    Label: 'General Information',
    Data: [
      { Value: vendorCode },
      { Value: vendorName },
      { Value: gstin },
      { Value: email },
      { Value: phone },
      { Value: address },
      { Value: city },
      { Value: country },
      { Value: paymentTerms }
    ]
  },
  UI.Facets: [{ $Type: 'UI.ReferenceFacet', Label: 'General Info', Target: '@UI.FieldGroup#GeneralInfo' }]
);

annotate PurchaseOrders with @(
  UI.HeaderInfo: { TypeName: 'Purchase Order', TypeNamePlural: 'Purchase Orders', Title: { Value: poNumber } },
  UI.LineItem: [
    { Value: poNumber,     Label: 'PO Number' },
    { Value: vendor.vendorName, Label: 'Vendor' },
    { Value: totalValue,   Label: 'Total Value (INR)' },
    { Value: status,       Label: 'Status' },
    { Value: deliveryDate, Label: 'Delivery Date' }
  ]
);

annotate PurchaseRequisitions with @(
  UI.HeaderInfo: { TypeName: 'Purchase Requisition', TypeNamePlural: 'Purchase Requisitions', Title: { Value: prNumber } },
  UI.LineItem: [
    { Value: prNumber,     Label: 'PR Number' },
    { Value: status,       Label: 'Status' },
    { Value: requestedBy,  Label: 'Requested By' },
    { Value: requiredDate, Label: 'Required Date' }
  ]
);

annotate GoodsReceipts with @(
  UI.HeaderInfo: { TypeName: 'Goods Receipt', TypeNamePlural: 'Goods Receipts', Title: { Value: grNumber } },
  UI.LineItem: [
    { Value: grNumber,     Label: 'GR Number' },
    { Value: po.poNumber,  Label: 'PO Number' },
    { Value: movementType, Label: 'Movement Type' },
    { Value: postingDate,  Label: 'Posting Date' },
    { Value: status,       Label: 'Status' }
  ]
);

annotate Invoices with @(
  UI.HeaderInfo: { TypeName: 'Invoice', TypeNamePlural: 'Invoices', Title: { Value: invoiceNo } },
  UI.LineItem: [
    { Value: invoiceNo,    Label: 'Invoice No.' },
    { Value: vendor.vendorName, Label: 'Vendor' },
    { Value: grossAmount,  Label: 'Gross Amount' },
    { Value: status,       Label: 'Status' },
    { Value: threeWayMatch, Label: '3-Way Match' },
    { Value: dueDate,      Label: 'Due Date' }
  ]
);
